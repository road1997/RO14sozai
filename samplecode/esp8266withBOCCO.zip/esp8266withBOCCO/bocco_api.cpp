
/** BOCCO API for Arduino
* bocco_api.cpp
* ESP8266用
* 71行目のenをjaに変えたりする
* 事で言語の設定ができます。
*/
#include "bocco_api.h"
#include <ESP8266WiFi.h>

BoccoAPI::BoccoAPI(char* email, char* password, char* apikey)
  :email(email), password(password), apikey(apikey){
}

/** GETする
 *
 */
String BoccoAPI::get(String url, String data, int retryCnt) {
#ifdef BOCCO_DEBUG
  Serial.println( "get" );
  Serial.println( " url "+url );
  Serial.println( " data "+data );
  Serial.println( " retryCnt "+String(retryCnt) );
#endif

  retryCnt--;
  if(retryCnt <= 0){
    //リトライ回数を超えた。
    return "";
  }
  Serial.println(BoccoAPI::PROTCOOL + BoccoAPI::HOST + url + "?" + data);
  this->client.begin(BoccoAPI::PROTCOOL + BoccoAPI::HOST + url + "?" + data,FingerPrint);
  this->client.addHeader("Accept-Language", "ja");
  this->client.addHeader("Content-Type","application/x-www-form-urlencoded;"); 
  int httpCode = this->client.GET(); 
  String response = ""; 
  if (httpCode > 0) {
    Serial.println(BoccoAPI::HOST + "GET... code:" + httpCode);
    response = client.getString();
  }else{
    Serial.println(BoccoAPI::HOST + "GET... failed, error: " + httpCode);
  }
  this->client.end();
#ifdef BOCCO_DEBUG
    Serial.println();
    Serial.print( "response.length " );
    Serial.println( response.length() );
    Serial.println( "response" );
    Serial.println( response );
#endif
    Serial.println();
    return response;
}

/** POSTする
 *
 */
String BoccoAPI::post(String url, String data, int retryCnt) {
#ifdef BOCCO_DEBUG
  Serial.println( "post" );
  Serial.println( " url "+url );
  Serial.println( " data "+data );
  Serial.println( " retryCnt "+String(retryCnt) );
#endif
  retryCnt--;
  if(retryCnt <= 0){
    //リトライ回数を超えた。
    return "";
  }
  
  Serial.println(BoccoAPI::PROTCOOL + BoccoAPI::HOST + url + "?" + data);
  this->client.begin(BoccoAPI::PROTCOOL + BoccoAPI::HOST + url + "?" + data,FingerPrint);
  this->client.addHeader("Accept-Language", "ja"); //jaをenに変えると英語を喋る。 
  //this->client.addHeader("Accept-Language", "en"); //en変更
  int httpCode = this->client.POST(""); 
  String response = "";
  if (httpCode > 0) {
    response = this->client.getString();
    Serial.println(BoccoAPI::HOST + " POST... code:" +  httpCode);
    Serial.println( response  );
  }else{
    Serial.println(BoccoAPI::HOST + "no connection or no HTTP server.ERRPR = " + httpCode);
  }
  
  this->client.end();
    if(httpCode == -1){
      //リトライする
      delay(BoccoAPI::RETRY_DELAY_SEC * 1000);
      return this->post(url,data,retryCnt);
    }
    Serial.println( "" );
    return response;
}

/** アクセストークンを取得
*
*/
bool BoccoAPI::createSessions(){
  //POSTパラメータを作る
  const String data = "apikey="+String(apikey)+"&email="+email+"&password="+password;

  //JSONを取得
  String json = this->post(BoccoAPI::API_SESSIONS,data, BoccoAPI::RETRY_CNT);

  //JSONパース
  StaticJsonBuffer<200> jsonBuffer;
  JsonObject& root = jsonBuffer.parseObject(json);
  if (!root.success()) {
    return false;
  }

  //アクセストークンを取得
  this->setAccessToken( root["access_token"] );

  return true;
}

/** アクセストークンを設定
 *
 */
void BoccoAPI::setAccessToken(const char* accessToken){
  this->accessToken = String(accessToken);
}

/** チャットルームを取得する
 *
 */
bool BoccoAPI::getFirstRoom(){
  //POSTパラメータを作る
  const String data = "access_token="+this->accessToken;
  //JSONを取得
  const String url = BoccoAPI::API_ROOMS+BoccoAPI::API_ROOMS_JOINED;
  String json = this->get(url,data,BoccoAPI::RETRY_CNT);

  //JSONパースするには大きすぎなので 1件目のルームデータだけ対象にする
  String room = json.substring( json.indexOf("[{\"uuid\":\"")+1 );
  room = room.substring( 0, room.indexOf("\"updated_at\"")-1 )+"}\n";
   //JSONパース
  StaticJsonBuffer<200> jsonBuffer;
  JsonObject& root = jsonBuffer.parseObject(room);
  if (!root.success()) {
    return false;
  }

  this->firstRoomId = String((const char*) root["uuid"]);

  return true;
}

/** メッセージをルームに送信する
 *
 */String makeUUID(byte a[]);
bool BoccoAPI::postMessageText(const char* text){
  //UUIDを生成
  byte uuidNumber[16];
  //ESP8266TrueRandom.uuid(uuidNumber);
  for(int i = 0; i<16;i++ ){
    uuidNumber[i] = random(0,255);
  }
  String uid = makeUUID(uuidNumber);//"0a51486c-a2de-4693-b036-7e9f02235482";//ESP8266TrueRandom.uuidToString(uuidNumber);
  //POSTパラメータを作る
  const String data = "access_token="+this->accessToken+"&unique_id="+uid + "&media=text&text="+String(text);
  const String url = BoccoAPI::API_ROOMS+"/"+this->firstRoomId+BoccoAPI::API_ROOMS_MESSAGES;
  
  //JSONを取得
  String json = this->post(url,data,BoccoAPI::RETRY_CNT);
  

  return true;
}
String makeUUID(byte a[]){
  String ans = "";
  int i = 0;
  for(; i < 4;i++){
    char sendPacket[2] = "";
    sprintf(sendPacket, "%02X", a[i]);
    ans += String(sendPacket);
  }ans += "-";
  for(; i < 6;i++){
    char sendPacket[2] = "";
    sprintf(sendPacket, "%02X", a[i]);
    ans += String(sendPacket);
  }ans += "-";
  for(; i < 8;i++){
    char sendPacket[2] = "";
    sprintf(sendPacket, "%02X", a[i]);
    ans += String(sendPacket);
  }ans += "-";
  for(; i < 10;i++){
    char sendPacket[2] = "";
    sprintf(sendPacket, "%02X", a[i]);
    ans += String(sendPacket);
  }ans += "-";
  for(; i < 16;i++){
    char sendPacket[2] = "";
    sprintf(sendPacket, "%02X", a[i]);
    ans += String(sendPacket);
  }
  Serial.println(ans);
  return ans;
}

/** 最新のメッセージIDを取得する
 *
 */

bool BoccoAPI::searchLatestMessageId() {

    //POSTパラメータを作る
    const String data = "access_token="+this->accessToken + "&newer_than=";
    //JSONを取得
    const String url = BoccoAPI::API_ROOMS + "/"
        + this->firstRoomId + BoccoAPI::API_ROOMS_MESSAGES;

    this->latestMessageId = -1;
    int id = 0;

#ifdef BOCCO_DEBUG
    Serial.println( "Searching latest message ID... " );
#endif

    while (this->latestMessageId == -1) {
        // 1回目はすべてのメッセージを取得する
        if (id == 0) {
            String json = this->get(url,data + id,BoccoAPI::RETRY_CNT);
            //JSONパースするには大きすぎなので 1件目のデータだけ対象にする
            String message = json.substring( json.indexOf("[{\"id\":")+1 );
            message = message.substring( 0, message.indexOf("\"unique_id\"")-1 )+"}\n";
            //JSONパース
            StaticJsonBuffer<100> jsonBuffer;
            JsonObject& root = jsonBuffer.parseObject(message);
            if (root.success()) {
                id = root["id"];
            }
            continue;
        }

        // 見つかったメッセージIDを追っていって最新のメッセージIDを見つける
        String json = this->get(url,data + id,BoccoAPI::RETRY_CNT);
        //JSONパースするには大きすぎなので 1件目のデータだけ対象にする
        String message = json.substring(json.indexOf("[{\"id\":"+1));
        message = message.substring( 0, message.indexOf("\"unique_id\"") - 1) + "}\n";

        //Serial.println("message");
        //Serial.println(message);
        //JSONパース
        StaticJsonBuffer<100> jsonBuffer;
        JsonObject& root = jsonBuffer.parseObject(message);
        message = json = "";

        if (!root.success()) {
            this->latestMessageId = id - 1;
        } else {
            id = root["id"];
        }

        delay(10);
    }

    return false;
}


int BoccoAPI::getLatestMessageId() {
    return this->latestMessageId;
}

