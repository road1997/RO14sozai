# BoccoEsp8266(esp-wroom-02)
[BOCCO API β](http://api-docs.bocco.me/index.html)  を [ESP8266 core for Arduino](https://github.com/esp8266/Arduino) で利用する為のライブラリ

| API | 実装 | 追加 権限 |
|:-----------:|:------------:|:------------:|
| アクセストークンの取得 | ◯ |  |
| チャットルームの取得 | ◯ |  |
| テキストメッセージの送信 | ◯ |  |
| 音声メッセージの送信 | ☓ |  |
| 画像メッセージの送信 | ☓ |  |
| メッセージ一覧の取得  | ☓ | ◯ |
| イベントの取得 | ☓ | ◯ |
| メッセージを既読にする | ☓ | ◯ |


## 依存
事前に以下のライブラリを利用しているので Arduino IDE でインストールしておく必要があります。  
[ESP8266 core for Arduino](https://github.com/esp8266/Arduino)  
[WiFiManager](https://github.com/tzapu/WiFiManager)  
[ArduinoJson](https://github.com/bblanchon/ArduinoJson)  
[ESP8266TrueRandom](https://github.com/marvinroger/ESP8266TrueRandom)  

## 用意するもの
[BOCCO ボッコ](http://amzn.to/2eLr8iD)  
[ESPr Developer（ESP-WROOM-02開発ボード）](http://amzn.to/2f6g4zw)  
電源回路やリセットスイッチ,タクトスイッチがついていてスケッチ開発に非常に便利なのでオススメです。  
[BOCCO API β](http://api-docs.bocco.me/index.html)    


## サンプル 実行方法
初回はアクセスポイントモードで起動してWiFi設定が済むと BOCCO API へのアクセスを確認することができます。  
1. STAモードで起動しているので、コードにssid,passwordを記入します。
2. espにファームを書き込みます。
3. 設定した WiFiに接続される。  
4. 1番目のルームにメッセージが送信され、BOCCO から再生される。      
