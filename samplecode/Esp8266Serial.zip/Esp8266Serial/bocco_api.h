/** BOCCO API for Arduino
* bocco_api.h
*/
#ifndef BoccoAPI_H_
#define BoccoAPI_H_

#include <arduino.h>
#include <ESP8266HTTPClient.h>
#include <ArduinoJson.h>

//デバッグを有効にする場合 定義する
#define BOCCO_DEBUG

class BoccoAPI
{
public:
 BoccoAPI(char* email, char* password, char* apikey);

public:
  bool createSessions();
  void setAccessToken(const char* accessToken);
  bool getFirstRoom();
  bool postMessageText(const char* text);
  bool searchLatestMessageId();
  int getLatestMessageId();
private:
  String get(String url, String data,int retryCnt);
  String post(String url, String data,int retryCnt);

private:
 HTTPClient client;
 char* email;
 char* password;
 char* apikey;

 String accessToken;
 String firstRoomId;
 int latestMessageId;

private:
 //ユーザーエージェント
 const String USER_AGENT = "ESP8266";

 //リトライ回数
 const int RETRY_CNT = 3;
 const int RETRY_DELAY_SEC = 3;

 const String PROTCOOL = "https://";
 const String HOST = "api.bocco.me";
 const int PORT = 443;

 const String API_SESSIONS = "/alpha/sessions";
 const String API_ROOMS = "/alpha/rooms";
 const String API_ROOMS_JOINED = "/joined";
 const String API_ROOMS_MESSAGES = "/messages";
 const String FingerPrint = "4D F3 40 A5 4E 86 B4 FD 46 CC 7F C7 AF 69 B1 01 E5 1F 48 29";
};

#endif
