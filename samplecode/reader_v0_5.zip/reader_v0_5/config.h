/** Bocco API 設定 サンプル
 *  
 */
 
//BOCCO アカウント情報
#define BOCCO_EMAIL     "noguchi.kiyomu.150693@roivy.net"
#define BOCCO_PASSWORD  "makamaka1329"
#define BOCCO_API_KEY   "ugu5rpQ58tuanZvTShdyRYsVcBsMRheIjS9l8NkcXIITpVG2NrlR8Ip5oYHjACuP"

//初期設定の為のアクセスポイント名
#define AP_NAME "hotgo_kaki"

